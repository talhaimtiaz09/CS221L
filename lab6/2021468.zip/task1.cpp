#include <iostream>
using namespace std;
void print(int arr[],int sz);

void _sort(int arr[], int sz)
{

    for (int step = 1; step < sz; step++)
    {
        if(step%2==0){

        int key = arr[step];
        int j = step - 2;

        while (key > arr[j] && j >= 0)
        {
            arr[j + 2] = arr[j];
            j-=2;
        }

        arr[j + 2] = key;

        cout<<"printing...\n";
        print(arr,sz);
        }
        else{
             int key = arr[step];
        int j = step-2 ;

        while (key < arr[j] && j >= 0)
        {
            arr[j + 2] = arr[j];
            j-=2;
        }

        arr[j + 2] = key;

        }
    }
}

void print(int arr[],int sz){
    for(int i=0;i<sz;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    int arr[] = {3, 4, 6, 2, 7, 1, 9, 10, 34, 12};
    int sz = sizeof(arr) / sizeof(arr[0]);
print(arr,sz);
    _sort(arr, sz);
print(arr,sz);

    return 0;
}